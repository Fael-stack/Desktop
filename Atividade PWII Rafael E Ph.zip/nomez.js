function nome(){
    defNome = document.getElementById('nome')
    defNome.innerHTML = `<h1>Curiosidade: Corinthians</h1>`
}