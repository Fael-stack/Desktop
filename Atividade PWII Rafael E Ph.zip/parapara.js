function paragrafo(){
    defTxt = document.getElementById("paragrafo")
    defTxt.innerHTML = 
    `<p>
    Sport Club Corinthians Paulista, conhecido como SCCP, é que o clube foi fundado em 1910 por um grupo de operários e, 
    desde então, tem uma forte ligação com a classe trabalhadora. 
    O Corinthians também foi um dos primeiros clubes brasileiros a ter uma torcida organizada, a "Gaviões da Fiel", que foi criada em 1969 e é conhecida por sua paixão e lealdade inabalável. A torcida é famosa por suas grandes festas e pela forma como apoia o time, tornando os jogos uma verdadeira celebração. Além disso, o Corinthians é um dos poucos clubes que conquistou o título da Copa do Mundo de Clubes da FIFA, em 2000 e 2012.
    </p>`
   }