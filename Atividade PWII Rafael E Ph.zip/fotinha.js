function foto(){
    defIMG = document.getElementById('foto');
    defIMG.innerHTML = `<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeTm8ZtFAliBMdrbKpVcRlOx7YPSKGCEakIQ&s">`
}